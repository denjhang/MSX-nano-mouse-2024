
Hi, 

The program source looks like crap at the moment, but most important parts work. I can't really recommend looking too much into it, so instead I write some simple instructions here...

Getting started:
-----------------

After programming the Arduino board succesfully with "MSXmouse.ino" and connecting mouse pins, test that the mouse communication works. This can be done by attaching mouse to Arduino and selecting "Serial monitor" from arduino IDE. Communication parameters are 9600,8N1. If program does not hang on "Initializing PS/2 mouse..." then you know that you have connected the mouse properly.

Before connecting to MSX you can now also setup the default operating mode. The current modes are:

1 = Mouse (Compatibility mode)
2 = Extended mouse only
3 = Extended mouse + Joystick
4 = Joystick
5 = Trackball
6 = Touchpad *

(* = Experimental: Very slow, but works somehow)

To select operating mode, start "Serial monitor" (or when connected to MSX, power on MSX) while holing down mouse button 2. After two seconds, you can release the button...

To select emulation mode (without saving as default) click the number of times mentioned before mode name to select operating mode and start the emulation by clicking button 2 again.

To select default emulation mode (will be saved to EEPROM until this process is executed again) click the number of times as earlier example, but on last click don't lift the button 1 up, but instead push the second button down at a same time.

Example, how to setup Symbos compatible mouse wheel support as default mouse mode:
- Hold down button 2
- Power on MSX
- wait until MSX-logo has disappeared.
- lift up button 2
- click button 1 once
- hold down button 1
- hold down button 2
- release both mouse buttons

If you have "InfoPin" connected (Most arduino boards have LED embedded to board on default pin 13) you can see the current mode during mouse boot (/after setup) by calculating the blinks. If you are connected to PC, you can also read the selected mode from serial.

In "Extended mouse"-modes you can't setup sensitivity as the wheel information is delivered to MSX.

Loader functionality (early alpha)
----------------------------------

NOTE: This is highly experimental feature and current version has been verified only with Arduino UNO & MSX tR running on R800. On Arduino Pro Nano this was very slow last time I tested, and I don't know what might be wrong... Propably not very usefull anyway...

Before starting:
- Plug Arduino to MSX joystick port 1
- Make sure that MSX joystick pin 5 is not connected to Arduino before plugging in USB-cable (I have used a switch here)
- Extract LOADER.RAW and SendFile.EXE to your Windows PC

Using:
- Start SendFile.EXE
- Type in Arduino's COM-port number.
- Browse for MSX standard BIN-file you want to run (as example I've added REDZONE.BIN)
- Click "Send"
- When asked to type "load command" type this line on MSX:

A=&HFA00:DEFUSR=A:FORI=0TO1:I=1+PAD(0):POKEA,PAD(1):A=A+1:NEXT:A=USR(0)

- Hit "Ok"

... The program will be loaded & started on MSX.


~NYYRIKKI
